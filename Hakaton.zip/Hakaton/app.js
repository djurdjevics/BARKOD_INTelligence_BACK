let inputQuantity = document.getElementById("kolicina");

let izKojeValute = document.getElementById("iz");

let uKojuValutu = document.getElementById("u");

let buttonSwitch = document.querySelector("#input3 button");

let buttonConvert = document.querySelector("#confirm button");

let what = document.getElementById("what");

let to_what = document.getElementById("to-what");

let timeStamp = document.getElementById("timeStapm");

let forEUR = document.getElementById("forEUR");
let forUSD = document.getElementById("forUSD");
let forJPY = document.getElementById("forJPY");

let calendar = document.getElementById("date");

let kvota_eur = document.getElementById("kvota-eur");
let kvota_usd = document.getElementById("kvota-usd");
let kvota_jpy = document.getElementById("kvota-jpy");

// Setup calendar

var today = new Date();
var dd = String(today.getDate()).padStart(2, "0");
var mm = String(today.getMonth() + 1).padStart(2, "0");
var yyyy = today.getFullYear();
today = yyyy + "-" + mm + "-" + dd;
calendar.value = today;
calendar.max = today;
calendar.min = "2000" + "-" + mm + "-" + dd;

// Switch button

buttonSwitch.addEventListener("click", () => {
  valuta1 = izKojeValute.value;
  valuta2 = uKojuValutu.value;
  izKojeValute.value = valuta2;
  uKojuValutu.value = valuta1;
});

// Convert

buttonConvert.addEventListener("click", () => {
  if (calendar.value == today) {
    //   Send request without date
    let request = new XMLHttpRequest();
    let izValute = izKojeValute.value;
    let uValutu = uKojuValutu.value;
    let iznos = inputQuantity.value;
    request.onreadystatechange = function () {
      if (this.readyState == 4) {
        if (this.status == 200) {
          // console.log(this.responseText);
          let result = JSON.parse(this.responseText);
          what.innerText = iznos + " " + izValute + " =";
          to_what.innerText = result.result + " " + uValutu;
          // Create a new JavaScript Date object based on the timestamp
          // multiplied by 1000 so that the argument is in milliseconds, not seconds.
          var date = new Date(result.timeStamp);
          // Hours part from the timestamp
          var hours = date.getHours();
          // Minutes part from the timestamp
          var minutes = "0" + date.getMinutes();
          // Seconds part from the timestamp
          var seconds = "0" + date.getSeconds();

          // Will display time in 10:30:23 format
          var formattedTime =
            hours + ":" + minutes.substr(-2) + ":" + seconds.substr(-2);

          console.log(formattedTime);
          timeStamp.innerText = "Konverzija je izvrsena u: " + formattedTime;
        }
      }
    };

    request.open(
      "GET",
      "https://barkod2021api.azurewebsites.net/Convert?fromCurr=" +
        izValute +
        "&toCurr=" +
        uValutu +
        "&amount=" +
        iznos
    );
    request.send();
  } else {
    let izValute = izKojeValute.value;
    let uValutu = uKojuValutu.value;
    let iznos = inputQuantity.value;
    let time = calendar.value;
    console.log(time);
    let request = new XMLHttpRequest();

    request.onreadystatechange = function () {
      if (this.readyState == 4) {
        if (this.status == 200) {
          console.log(this.responseText);
          let result = JSON.parse(this.responseText);
          what.innerText = iznos + " " + izValute + " =";
          to_what.innerText = result.result + " " + uValutu;
        }
      }
    };

    request.open(
      "GET",
      "https://barkod2021api.azurewebsites.net//convertWithHistoricalDate?fromCurr=" +
        izValute +
        "&toCurr=" +
        uValutu +
        "&amount=" +
        iznos +
        "&time=" +
        time
    );
    request.send();
  }
});

// Load data od page load

let mainRequestEUR = new XMLHttpRequest();

mainRequestEUR.onreadystatechange = function () {
  if (this.readyState == 4) {
    if (this.status == 200) {
      // console.log(this.responseText);
      let result = JSON.parse(this.responseText);
      forEUR.innerText = result["EURRSD"];
    }
  }
};

mainRequestEUR.open(
  "GET",
  "https://barkod2021api.azurewebsites.net/GetRSDQuotes?toCurr=EUR"
);
mainRequestEUR.send();

let mainRequestUSD = new XMLHttpRequest();

mainRequestUSD.onreadystatechange = function () {
  if (this.readyState == 4) {
    if (this.status == 200) {
      // console.log(this.responseText);
      let result = JSON.parse(this.responseText);
      forUSD.innerText = result["USDRSD"];
    }
  }
};

mainRequestUSD.open(
  "GET",
  "https://barkod2021api.azurewebsites.net/GetRSDQuotes?toCurr=USD"
);
mainRequestUSD.send();

let mainRequestJPY = new XMLHttpRequest();

mainRequestJPY.onreadystatechange = function () {
  if (this.readyState == 4) {
    if (this.status == 200) {
      // console.log(this.responseText);
      let result = JSON.parse(this.responseText);
      forJPY.innerText = result["JPYRSD"];
    }
  }
};

mainRequestJPY.open(
  "GET",
  "https://barkod2021api.azurewebsites.net/GetRSDQuotes?toCurr=JPY"
);
mainRequestJPY.send();

let resultMonth = null;

kvota_eur.addEventListener("click", () => {
  let request = new XMLHttpRequest();
  request.onreadystatechange = function () {
    if (this.readyState == 4) {
      if (this.status == 200) {
        console.log(this.responseText);
        let result = JSON.parse(this.responseText);
        console.log(result);
        resultMonth = [];
        avg = 0;

        for (let i = 0; i < 30; i++) {
          resultMonth.push(result[i]["currency"]);
          if (i != 0) {
            avg += result[i]["currency"];
          }
        }
        // CHART
        let myChart = document.getElementById("myChart").getContext("2d");

        // Global Options
        Chart.defaults.global.defaultFontFamily = "Lato";
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = "#777";

        let massPopChart = new Chart(myChart, {
          type: "line", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
          data: {
            labels: [
              "1.",
              "2.",
              "3.",
              "4.",
              "5.",
              "6.",
              "7.",
              "8.",
              "9.",
              "10.",
              "11.",
              "12.",
              "13.",
              "14.",
              "15.",
              "16.",
              "17.",
              "18.",
              "19.",
              "20.",
              "21.",
              "22.",
              "23.",
              "24.",
              "25.",
              "26.",
              "27.",
              "28.",
              "29.",
              "30.",
            ],
            datasets: [
              {
                label: "Cena",
                data: resultMonth,
                //backgroundColor:'green',
                backgroundColor: [
                  "rgba(26, 18, 41, 0.6)",
                  "rgba(54, 162, 235, 0.6)",
                  "rgba(255, 206, 86, 0.6)",
                  "rgba(75, 192, 192, 0.6)",
                  "rgba(153, 102, 255, 0.6)",
                  "rgba(255, 159, 64, 0.6)",
                  "rgba(255, 99, 132, 0.6)",
                ],
                borderWidth: 1,
                borderColor: "#777",
                hoverBorderWidth: 3,
                hoverBorderColor: "#000",
              },
            ],
          },
          options: {
            title: {
              display: true,
              text: "EUR->RSD",
              fontSize: 25,
            },
            legend: {
              display: true,
              position: "right",
              labels: {
                fontColor: "#000",
              },
            },
            layout: {
              padding: {
                left: 50,
                right: 0,
                bottom: 0,
                top: 0,
              },
            },
            tooltips: {
              enabled: true,
            },
          },
        });
      }
    }
  };
  request.open(
    "GET",
    "https://barkod2021api.azurewebsites.net//getParamsForMonth?fromCurr=EUR"
  );
  request.send();
});

kvota_usd.addEventListener("click", () => {
  let request = new XMLHttpRequest();
  request.onreadystatechange = function () {
    if (this.readyState == 4) {
      if (this.status == 200) {
        // console.log(this.responseText);
        let result = JSON.parse(this.responseText);
        // console.log(result)
        resultMonth = [];
        for (let i = 0; i < 30; i++) {
          resultMonth.push(result[i]["currency"]);
        }
        // CHART
        let myChart = document.getElementById("myChart").getContext("2d");

        // Global Options
        Chart.defaults.global.defaultFontFamily = "Lato";
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = "#777";

        let massPopChart = new Chart(myChart, {
          type: "line", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
          data: {
            labels: [
              "1.",
              "2.",
              "3.",
              "4.",
              "5.",
              "6.",
              "7.",
              "8.",
              "9.",
              "10.",
              "11.",
              "12.",
              "13.",
              "14.",
              "15.",
              "16.",
              "17.",
              "18.",
              "19.",
              "20.",
              "21.",
              "22.",
              "23.",
              "24.",
              "25.",
              "26.",
              "27.",
              "28.",
              "29.",
              "30.",
            ],
            datasets: [
              {
                label: "Cena",
                data: resultMonth,
                //backgroundColor:'green',
                backgroundColor: [
                  "rgba(26, 18, 41, 0.6)",
                  "rgba(54, 162, 235, 0.6)",
                  "rgba(255, 206, 86, 0.6)",
                  "rgba(75, 192, 192, 0.6)",
                  "rgba(153, 102, 255, 0.6)",
                  "rgba(255, 159, 64, 0.6)",
                  "rgba(255, 99, 132, 0.6)",
                ],
                borderWidth: 1,
                borderColor: "#777",
                hoverBorderWidth: 3,
                hoverBorderColor: "#000",
              },
            ],
          },
          options: {
            title: {
              display: true,
              text: "USD->RSD",
              fontSize: 25,
            },
            legend: {
              display: true,
              position: "right",
              labels: {
                fontColor: "#000",
              },
            },
            layout: {
              padding: {
                left: 50,
                right: 0,
                bottom: 0,
                top: 0,
              },
            },
            tooltips: {
              enabled: true,
            },
          },
        });
      }
    }
  };
  request.open(
    "GET",
    "https://barkod2021api.azurewebsites.net//getParamsForMonth?fromCurr=USD"
  );
  request.send();
});

kvota_jpy.addEventListener("click", () => {
  let request = new XMLHttpRequest();
  request.onreadystatechange = function () {
    if (this.readyState == 4) {
      if (this.status == 200) {
        console.log(this.responseText);
        let result = JSON.parse(this.responseText);
        console.log(result);
        resultMonth = [];
        for (let i = 0; i < 30; i++) {
          resultMonth.push(result[i]["currency"]);
        }
        console.log(resultMonth);
        // CHART
        let myChart = document.getElementById("myChart").getContext("2d");

        // Global Options
        Chart.defaults.global.defaultFontFamily = "Lato";
        Chart.defaults.global.defaultFontSize = 18;
        Chart.defaults.global.defaultFontColor = "#777";

        let massPopChart = new Chart(myChart, {
          type: "line", // bar, horizontalBar, pie, line, doughnut, radar, polarArea
          data: {
            labels: [
              "1.",
              "2.",
              "3.",
              "4.",
              "5.",
              "6.",
              "7.",
              "8.",
              "9.",
              "10.",
              "11.",
              "12.",
              "13.",
              "14.",
              "15.",
              "16.",
              "17.",
              "18.",
              "19.",
              "20.",
              "21.",
              "22.",
              "23.",
              "24.",
              "25.",
              "26.",
              "27.",
              "28.",
              "29.",
              "30.",
            ],
            datasets: [
              {
                label: "Cena",
                data: resultMonth,
                //backgroundColor:'green',
                backgroundColor: [
                  "rgba(26, 18, 41, 0.6)",
                  "rgba(54, 162, 235, 0.6)",
                  "rgba(255, 206, 86, 0.6)",
                  "rgba(75, 192, 192, 0.6)",
                  "rgba(153, 102, 255, 0.6)",
                  "rgba(255, 159, 64, 0.6)",
                  "rgba(255, 99, 132, 0.6)",
                ],
                borderWidth: 1,
                borderColor: "#777",
                hoverBorderWidth: 3,
                hoverBorderColor: "#000",
              },
            ],
          },
          options: {
            title: {
              display: true,
              text: "JPY->RSD",
              fontSize: 25,
            },
            legend: {
              display: true,
              position: "right",
              labels: {
                fontColor: "#000",
              },
            },
            layout: {
              padding: {
                left: 50,
                right: 0,
                bottom: 0,
                top: 0,
              },
            },
            tooltips: {
              enabled: true,
            },
          },
        });
      }
    }
  };
  request.open(
    "GET",
    "https://barkod2021api.azurewebsites.net//getParamsForMonth?fromCurr=JPY"
  );
  request.send();
});

let mainRequest_param = new XMLHttpRequest();
let params = "";

mainRequest_param.onreadystatechange = function () {
  if (this.readyState == 4) {
    if (this.status == 200) {
      params = this.responseText;
      console.log(params);
      forEUR.innerText =
        forEUR.innerText +
        "  |  " +
        (100 - params.split(";")[0]).toString() +
        "%";
      forUSD.innerText =
        forUSD.innerText +
        "  |  " +
        (100 - params.split(";")[1]).toString() +
        "%";
      forJPY.innerText =
        forJPY.innerText +
        "  |  " +
        (100 - params.split(";")[2]).toString() +
        "%";
      if (params.split(";")[0] > 0) {
        forEUR.classList.add("green");
      } else if (params.split(";")[0] == 0) {
        forEUR.classList.add("yellow");
      } else {
        forEUR.classList.add("red");
      }

      if (params.split(";")[1] > 0) {
        forUSD.classList.add("green");
      } else if (params.split(";")[1] == 0) {
        forUSD.classList.add("yellow");
      } else {
        forUSD.classList.add("red");
      }

      if (params.split(";")[2] > 0) {
        forJPY.classList.add("green");
      } else if (params.split(";")[2] == 0) {
        forJPY.classList.add("yellow");
      } else {
        forJPY.classList.add("red");
      }
    }
  }
};

mainRequest_param.open(
  "GET",
  "https://barkod2021api.azurewebsites.net/percent"
);
mainRequest_param.send();
