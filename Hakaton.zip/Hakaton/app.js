let inputQuantity = document.getElementById("kolicina");

let izKojeValute = document.getElementById("iz");

let uKojuValutu = document.getElementById("u");

let buttonSwitch = document.querySelector("#input3 button");

let buttonConvert = document.querySelector("#confirm button");

let forEUR = document.querySelector("kvota-eur span");
let forUSD = document.querySelector("kvota-usd span");
let forJPY = document.querySelector("kvota-jpy span");

let calendar = document.getElementById("date");

// Setup calendar

var today = new Date();
var dd = String(today.getDate()).padStart(2, "0");
var mm = String(today.getMonth() + 1).padStart(2, "0");
var yyyy = today.getFullYear();
today = yyyy + "-" + mm + "-" + dd;
calendar.value = today;
calendar.max = today;
calendar.min = "2000" + "-" + mm + "-" + dd;

// Switch button

buttonSwitch.addEventListener("click", () => {
  valuta1 = izKojeValute.value;
  valuta2 = uKojuValutu.value;
  izKojeValute.value = valuta2;
  uKojuValutu.value = valuta1;
});

// Convert

buttonConvert.addEventListener("click", () => {
  if (calendar.value == today) {
    //   Send request without date
    let request = new XMLHttpRequest();

    request.onreadystatechange = function () {
      if (this.readyState == 4) {
        if (this.status == 200) {
        }
      }
    };

    request.open(
      "GET",
      "https://web-dizajn-projekat-sv-57-2020-default-rtdb.firebaseio.com/gradovi.json"
    );
    request.send();
  } else {
    //   Send request with date
    let request = new XMLHttpRequest();

    request.onreadystatechange = function () {
      if (this.readyState == 4) {
        if (this.status == 200) {
        }
      }
    };

    request.open(
      "GET",
      "https://web-dizajn-projekat-sv-57-2020-default-rtdb.firebaseio.com/gradovi.json"
    );
    request.send();
  }
});

// Load data od page load

let mainRequest = new XMLHttpRequest();

mainRequest.onreadystatechange = function () {
  if (this.readyState == 4) {
    if (this.status == 200) {
      console.log(this.responseText);
    }
  }
};

mainRequest.open(
  "GET",
  "https://barkod2021api.azurewebsites.net/Convert?fromCurr=EUR&toCurr=RSD&amount=150"
);
mainRequest.send();
